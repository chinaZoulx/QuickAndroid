package com.example.chriszou.quicksample.ui.main.mycenter

import com.example.chriszou.quicksample.R
import org.quick.library.b.BaseActivity

class QSwipeRefreshLayoutActivity:BaseActivity() {
    override fun onResultLayoutResId(): Int = R.layout.activity_q_swiperefreshlayout
    override fun onInit() {

    }

    override fun onInitLayout() {

    }

    override fun onBindListener() {

    }

    override fun start() {

    }
}