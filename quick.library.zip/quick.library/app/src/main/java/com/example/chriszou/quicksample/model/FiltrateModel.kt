package com.example.chriszou.quicksample.model

class FiltrateModel(var filtrateKey: String = "", var filtrateId: String = "") : org.quick.library.m.DBManager()