package com.example.chriszou.quicksample

class MainApplication:org.quick.library.b.BaseTinkerApplication() {
    override fun onInit() {

    }

    override fun onResultBugglyAppId(): String ="b39b69c63c"
}