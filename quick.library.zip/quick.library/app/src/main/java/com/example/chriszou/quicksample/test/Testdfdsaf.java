package com.example.chriszou.quicksample.test;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;

public class Testdfdsaf {

//    Testdfdsaf(Context activity, int res) {
//        this(activity, null);
//        View view = LayoutInflater.from(activity).inflate(res, null);
//        view.setId(res);
//
//    }
//
//    Testdfdsaf(Context activity, View style) {
//        conte
//    }
}
