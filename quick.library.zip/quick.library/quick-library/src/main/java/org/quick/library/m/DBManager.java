package org.quick.library.m;


import org.litepal.crud.DataSupport;

/**
 * 数据库管理
 * @url https://github.com/LitePalFramework/LitePal
 * @author chris
 * @Date 16/9/23
 * @modifyInfo1 chris-16/9/23
 * @modifyContent
 */

public class DBManager extends DataSupport {

    public static final String TAG="DBManager";

}
