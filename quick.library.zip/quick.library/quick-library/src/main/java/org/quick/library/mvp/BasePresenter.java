package org.quick.library.mvp;

/**
 * Created by work on 2017/6/2.
 *
 * @author chris zou
 * @mail chrisSpringSmell@gmail.com
 */

public interface BasePresenter {

    void start();
}
