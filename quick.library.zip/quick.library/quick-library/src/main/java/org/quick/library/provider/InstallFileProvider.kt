package org.quick.library.provider

import androidx.core.content.FileProvider

/**
 * Created by ChrisZou on 2018/4/23.
 */
class InstallFileProvider:FileProvider() {
}